import java.util.*;

public class functionStruct{
    public String functionName;
    public int lineNumber;

    public functionStruct (){
        functionName="fuck";
        lineNumber = -1;
    }
}